document.getElementById('fillButton').addEventListener('click', function() {
    const juice = document.querySelector('.juice');
    const bottleBody = document.querySelector('.bottle-body');
    const fillButton = this;

    // Prevent refilling if already in progress or filled
    if (juice.classList.contains('filling') || juice.classList.contains('filled')) {
        return;
    }

    juice.classList.add('filling'); // Mark as filling
    fillButton.disabled = true; // Disable button during fill

    const targetHeightPercentage = 90; // Fill to 90% of the bottle body
    const totalFillTime = 5000; // 5 seconds to fill
    const startTime = performance.now(); // Get current time for animation timing

    function animateFill(currentTime) {
        const elapsedTime = currentTime - startTime;
        let progress = Math.min(elapsedTime / totalFillTime, 1); // Clamp progress between 0 and 1

        // Apply a subtle ease-in-out curve to the filling for a natural feel
        // This makes it start and end a bit slower, middle faster
        progress = -(Math.cos(Math.PI * progress) - 1) / 2;

        const currentHeight = progress * targetHeightPercentage;
        juice.style.height = `${currentHeight}%`;

        // Activate wave effect once juice starts to appear
        if (currentHeight > 5 && !juice.classList.contains('filled')) {
            juice.classList.add('filled'); // 'filled' class now controls wave, not total height
        }

        if (progress < 1) {
            requestAnimationFrame(animateFill); // Continue animation
        } else {
            // Animation finished
            juice.classList.remove('filling');
            fillButton.textContent = 'Bottle Filled!';
            // The 'filled' class remains to keep the wave active
        }
    }

    requestAnimationFrame(animateFill); // Start the animation loop
});